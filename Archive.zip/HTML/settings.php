<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> Home Utilities Manager &ndash; </title>
	<link rel="stylesheet" href="../CSS/pure-min.css">
	<link rel="stylesheet" type="text/css" href="../CSS/normalize.css"/>
	<link rel="stylesheet" type="text/css" href="../CSS/settings.css"/>

	<!--[if lte IE 8]>
		<link rel="stylesheet" href="/combo/1.18.13?/css/layouts/side-menu-old-ie.css">
	<![endif]-->
	<!--[if gt IE 8]><!-->
	<!--<![endif]-->
	<!--[if lt IE 9]>
	<script src="http://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7html5shiv.js"></script>
	<![endif]-->

</head>
</html>
