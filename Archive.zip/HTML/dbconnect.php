<?php
      define('DB_SERVER', '152.117.180.234:3306');
      define('DB_USERNAME', 'remote');
      define('DB_PASSWORD', 'getserved69');
      define('DB_DATABASE', 'sys');
      $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
